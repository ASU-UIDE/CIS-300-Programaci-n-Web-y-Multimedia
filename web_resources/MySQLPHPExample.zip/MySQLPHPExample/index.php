<?php
# Welcome to myTravel 

require_once "sampdb_pdo.php";

$title = "Welcome to myTravel";
html_begin ($title, $title);
?>

<p>
<a href="gallery.html">View</a> Gallery
</p>
<p>
<a href="AgentInfo.php">Display and ADD</a> Agent info
</p>

<?php
html_end ();
?>
