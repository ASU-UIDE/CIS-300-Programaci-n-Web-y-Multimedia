<html>
<title>HTML with PHP</title>
<body>
<p>
<a href="index.php">Back to Home Page</a>
</p>

<?php
#@ _OUTLINE_PART_1_
# AgentInfo.php - Add and display agent info

require_once "sampdb_pdo.php";

# define action constants
define ("SHOW_INITIAL_PAGE", 0);
define ("GET_NEW_AGENT_INFO", 1);
define ("ADD_AGENT", 2);
define ("DISPLAY_SCORES", 3);
define ("ENTER_SCORES", 4);
#@ _OUTLINE_PART_1_

#@ _DISPLAY_CELL_
# Display a cell of an HTML table.  $tag is the tag name ("th" or "td"
# for a header or data cell), $value is the value to display, and
# $encode should be true or false, indicating whether or not to perform
# HTML-encoding of the value before displaying it.  $encode is optional,
# and is true by default.

function display_cell ($tag, $value, $encode = TRUE)
{
  if (strlen ($value) == 0) # is the value empty/unset?
    $value = "&nbsp;";
  else if ($encode) # perform HTML-encoding if requested
    $value = htmlspecialchars ($value);
  print ("<$tag>$value</$tag>\n");
}
#@ _DISPLAY_CELL_

# Display a list of the existing grade events.  User can select any
# of them to add or edit scores for that event.  There is also a "new
# event" link for creating a new event.

#@ _DISPLAY_AGENTS_
function display_agents ($dbh)
{
  print ("Agent Information\n");
  print ("Click on Add a new agent link to add a new agent<br /><br />\n");
  print ("<table border=\"1\">\n");

  # Print a row of table column headers

  print ("<tr>\n");
  display_cell ("th", "Agent ID");
  display_cell ("th", "First Name");
  display_cell ("th", "Last Name");
  display_cell ("th", "Phone Number");
  display_cell ("th", "Email");
  print ("</tr>\n");

  # Present list of events.  Associate each event ID
  # with a link that shows the scores for the event.

  $stmt = "SELECT *
           FROM agents ";
  $sth = $dbh->query ($stmt);

  while ($row = $sth->fetch ())
  {
    print ("<tr>\n");
    $url = sprintf ("%s?action=%d&idAgents=%d",
                    script_name (),
                    DISPLAY_SCORES,
                    $row["idAgents"]);
//    display_cell ("td",
//                  "<a href=\"$url\">"
//                    . $row["idAgents"]
//                    . "</a>",
//                  FALSE);
    display_cell ("td", $row["idAgents"]);
    display_cell ("td", $row["First_Name"]);
    display_cell ("td", $row["Last_Name"]);
	display_cell ("td", $row["Phone_Number"]);
    display_cell ("td", $row["Email"]);
    print ("</tr>\n");
  }

  # Add one more link for creating a new event

  print ("<tr align=\"center\">\n");
  $url = sprintf ("%s?action=%d",
                  script_name (),
                  GET_NEW_AGENT_INFO);
  display_cell ("td colspan=\"5\"",
                "<a href=\"$url\">Add a new Agent</a>",
                FALSE);
  print ("</tr>\n");

  print ("</table>\n");
}
#@ _DISPLAY_AGENTS_

# Present form to solicit information for new event

#@ _GET_NEW_AGENT_INFO_
function new_agent_info ()
{
  printf ("<form method=\"post\" action=\"%s?action=%d\">\n",
          script_name (),
          ADD_AGENT);
  print ("Enter information for new agent:<br /><br />\n");
  print ("First Name: ");
  print ("<input type=\"text\" name=\"fName\" value=\"\" size=\"30\" />\n");
  print ("<br /><br />\n");
  print ("Last Name: ");
  print ("<input type=\"text\" name=\"lName\" value=\"\" size=\"30\" />\n");
  print ("<br /><br />\n");
  print ("Phone Number: ");
  print ("<input type=\"text\" name=\"pNumber\" value=\"\" size=\"30\" />\n");
  print ("<br /><br />\n");
  print ("Email: ");
  print ("<input type=\"text\" name=\"Email\" value=\"\" size=\"30\" />\n");
  print ("<br /><br />\n");
  //print ("Category: ");
  //print ("<input type=\"radio\" name=\"category\" value=\"T\"");
  //print (" checked=\"checked\" />Test\n");
  //print ("<input type=\"radio\" name=\"category\" value=\"Q\" />Quiz\n");
  print ("<br /><br />\n");
  print ("<input type=\"submit\" name=\"submit\" value=\"Submit\" />\n");
  print ("</form>\n");
}
#@ _GET_NEW_AGENT_INFO_

# Add new event to event table

#@ _ADD_NEW_AGENT_
function add_new_agent ($dbh)
{
  $fName = script_param ("fName");          # get First Name
  $lName = script_param ("lName");          # get Last Name
  $pNumber = script_param ("pNumber");        # get Phone Number
  $Email = script_param ("Email");          # get Email
  

  if (empty ($fName))  # make sure a first name was entered, and in ISO 8601 format
    die ("No First Name specified\n");
  if (empty ($lName))  # make sure a last name was entered, and in ISO 8601 format
    die ("No Last Name specified\n");
  if (empty ($pNumber))  # make sure a phone number was entered, and in ISO 8601 format
    die ("No Phone number specified\n");
  if (empty ($Email))  # make sure a email was entered, and in ISO 8601 format
    die ("No Email specified\n");	
// if (!preg_match ('/^\d{4}\D\d{1,2}\D\d{1,2}$/', $date))
//    die ("Please enter the date in ISO 8601 format (CCYY-MM-DD)\n");
//  if ($category != "T" && $category != "Q")
//    die ("Bad event category\n");

  $stmt = "INSERT INTO agents (First_Name, Last_Name, Phone_Number, Email) VALUES(?,?,?,?)";
  $sth = $dbh->prepare ($stmt);
  $sth->execute (array ($fName, $lName, $pNumber, $Email));
}
#@ _ADD_NEW_AGENT_

# Display all scores for a given event, sorted by student name.
# Names are displayed as static text, scores as editable fields.

#@ _DELETE_AGENTS_
function delete_agents ($dbh)
{
  # Get Agent ID number

  $idAgents = script_param ("idAgents");

  if (!ctype_digit ($idAgents)) # must look like integer
    die ("Bad event ID\n");

  # Prepare the statements that are executed repeatedly
  $sth_del = $dbh->prepare ("DELETE FROM agents
                             WHERE idAgents = ? ");

  # Enter scores within a transaction
 
}
#@ _ENTER_SCORES_

#@ _OUTLINE_PART_2_
$title = "myTravel Agent Information";
html_begin ($title, $title);

$dbh = sampdb_connect ();

# Determine what action to perform (the default is to
# present the initial page if no action is specified)

#@ _GET_ACTION_PARAM_
$action = script_param ("action");
#@ _GET_ACTION_PARAM_
if (is_null ($action))
  $action = SHOW_INITIAL_PAGE;

switch ($action)
{
case SHOW_INITIAL_PAGE:   # present initial page
  display_agents ($dbh);
  break;
case GET_NEW_AGENT_INFO:       # ask for new agent information
  new_agent_info ();
  break;
case ADD_AGENT:           # add new agent to database
  add_new_agent ($dbh);
  display_agents ($dbh);
  break;
case DISPLAY_AGENTS:      # display agents for selected agent
  display_agents ($dbh);
  break;
case DELETE_AGENTS:        # enter new or edited scores
  delete_agents ($dbh);
  display_agents ($dbh);
  break;
default:
  die ("Unknown action code ($action)\n");
}

$dbh = NULL;  # close connection

html_end ();
#@ _OUTLINE_PART_2_
?>

</body>
</html>